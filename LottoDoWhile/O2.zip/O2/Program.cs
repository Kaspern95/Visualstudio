﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ObligatoriskOpgave
{

    class Program
    {
        private static Random rnd = new Random();
        private static readonly int antalJokerRaekker = 2;
        private static readonly int antalLottoTalPrRaekke = 7;
        private static readonly int antalJokerTalPrRaekke = 7;

        static void Main(string[] args)
        {
            bool koebJokerTal = GetKoebJokerTal();
            int antalRaekker = GetAntalLottoRaekker();

            UdskrivLottoHeader();
            GenererLottoKupon(antalRaekker);

            if (koebJokerTal)
            {
                GenerereJokerKupon();
            }
        }

        private static int GetAntalLottoRaekker()
        {
            Console.Write(" Hvor mange rækker skal der være på din lotto kupon? ");

            string antalRaekker = Console.ReadLine();
            return Convert.ToInt32(antalRaekker);
        }

        private static bool GetKoebJokerTal()
        {
            Console.Write("Vil du købe jokertal på din lottokupon [J]a eller [N]ej? ");

            string svar = Console.ReadLine();
            return svar.ToUpper() == "J";
        }

        static void UdskrivLottoHeader()
        {

            string lottodate;
            lottodate = DateTime.Now.ToString("dd-MM-yyyy");
            Console.WriteLine("\tLotto " + lottodate + "\n");
            Console.WriteLine("\t     1 - Uge");
            Console.WriteLine("\t    LYN-LOTTO\n");

            Console.WriteLine();
        }

        private static int GenererLottoTal()
        {
            return rnd.Next(1, 37);
        }


        private static void GenererLottoKupon(int antalRaekker)
        {

            int[,] lotto = new int[antalRaekker, antalLottoTalPrRaekke];

            for (int i = 0; i < lotto.GetLength(0); i++)
            {
                Console.Write($"   {i + 1,2}.");
                for (int j = 0; j < lotto.GetLength(1); j++)
                {
                    int nytTal;
                    bool exists = true;
                    do
                    {
                        nytTal = GenererLottoTal();
                        exists = false;
                        for (int k = 0; k < j; k++)
                        {
                            if (lotto[i, k] == nytTal)
                            {
                                exists = true;
                            }
                        }

                    } while (exists);
                     lotto[i, j] = nytTal;
                    Console.Write($" {lotto[i, j],2:d2}");
                }

                Console.WriteLine();
            }
        }

        private static int GenererJokerTal()
        {
            return rnd.Next(1, 10);
        }

        private static void GenerereJokerKupon()
        {

            Console.WriteLine("\n   *******Joker tal*********\n");
            int[,] joker = new int[antalJokerRaekker, antalJokerTalPrRaekke];
            for (int i = 0; i < joker.GetLength(0); i++)
            {
                Console.Write("    ");
                for (int j = 0; j < joker.GetLength(1); j++)
                {
                    joker[i, j] = GenererJokerTal();
                    Console.Write($"  {joker[i, j]}");
                }
                Console.WriteLine();

            }
            Console.WriteLine();
        }
    }
}


