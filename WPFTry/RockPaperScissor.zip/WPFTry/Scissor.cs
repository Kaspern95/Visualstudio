﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WPFTry
{
    class Scissor
    {
        public string name;
        public int number;
        public Scissor(string name, int number)
        {
            this.name = name;
            this.number = number;
        }
    }
}
