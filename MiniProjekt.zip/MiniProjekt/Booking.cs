﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MiniProjekt
{
    class Booking
    {
        private DateTime now;
        private DateTime dateTime;
        private object v;

        public int Id { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public object Product { get; set; }

        public Booking(DateTime startDate, DateTime endDate, object product)
        {
            StartDate = startDate;
            EndDate = endDate;
            Product = product;
        }

        public Booking(int id, DateTime startDate, DateTime endDate, object product)
        {
            Id = id;
            StartDate = startDate;
            EndDate = endDate;
            Product = product;
        }
    }
}
