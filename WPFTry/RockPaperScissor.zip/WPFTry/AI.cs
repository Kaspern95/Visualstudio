﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WPFTry
{
    class AI
    {
        public int number;
        public AI(int number)
        {
            this.number = number;
        }
    }
}
