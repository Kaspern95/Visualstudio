﻿namespace WPFTry
{
    class Rock
    {
        public string rock;
        public int number;

        public Rock(string rock, int number)
        {
            this.rock = rock;
            this.number = number;
        }


    }
}
